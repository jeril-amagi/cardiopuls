<?php ob_start() ?>
<?php
if ($_GET['randomId'] != "hFFHaOjY87TwBd5jSZZR1dfkD4XioeRJuAcDQnyBO6Q796cyTVMMtef6Q8a0opfNMOjSzTu43iQYbUH74hZFdscwcdJuYAmpibmjtnsYKRPqVrZ9cemMeE8pw3lbPD3PFsRb6jh_MxoCeXOcTkTqWOPMHMxf9L0c7U70z4E3xy8mSTw5h2HZbsttnXOHozKQXc94iWMbltDbJQR5Lyj3c5al576pxH3xgcpJelBPN2CErVPhl7YJe012UsGVnN9P") {
    echo "Access Denied";
    exit();
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Editing home.html</title>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<style type="text/css">body {background-color:threedface; border: 0px 0px; padding: 0px 0px; margin: 0px 0px}</style>
</head>
<body>
<div align="center">

<div id="saveform" style="display:none;">
<form METHOD="POST" name=mform action="https://host110.hosting.register.com:2083/frontend/x3/filemanager/savehtmlfile.html">
    <input type="hidden" name="charset" value="ISO-8859-1">
    <input type="hidden" name="baseurl" value="http://www.cardiopuls.com/public_html/">
    <input type="hidden" name="basedir" value="/home/p15lh0tm/public_html/">
    <input type="hidden" name="udir" value="/home/p15lh0tm/public_html">
    <input type="hidden" name="ufile" value="home.html">
    <input type="hidden" name="dir" value="%2fhome%2fp15lh0tm%2fpublic_html">
    <input type="hidden" name="file" value="home.html">
    <input type="hidden" name="doubledecode" value="1">
<textarea name=page rows=1 cols=1></textarea></form>
</div>
<div id="abortform" style="display:none;">
<form METHOD="POST" name="abortform" action="https://host110.hosting.register.com:2083/frontend/x3/filemanager/aborthtmlfile.html">
    <input type="hidden" name="charset" value="ISO-8859-1">
    <input type="hidden" name="baseurl" value="http://www.cardiopuls.com/public_html/">
    <input type="hidden" name="basedir" value="/home/p15lh0tm/public_html/">
    <input type="hidden" name="dir" value="%2fhome%2fp15lh0tm%2fpublic_html">
        <input type="hidden" name="file" value="home.html">
    <input type="hidden" name="udir" value="/home/p15lh0tm/public_html">
    <input type="hidden" name="ufile" value="home.html">

        </form>
</div>
<script language="javascript">
<!--//

function setHtmlFilters(editor) {
// Design view filter
editor.addHTMLFilter('design', function (editor, html) {
        return html.replace(/\<meta\s+http\-equiv\="Content\-Type"[^\>]+\>/gi, '<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />');
});

// Source view filter
editor.addHTMLFilter('source', function (editor, html) {
        return html.replace(/\<meta\s+http\-equiv\="Content\-Type"[^\>]+\>/gi, '<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />');
});
}

// this function updates the code in the textarea and then closes this window
function do_save() {
    document.mform.page.value = WPro.editors[0].getValue();
	document.mform.submit();
}
function do_abort() {
	document.abortform.submit();
}
//-->
</script>
<?php
// make sure these includes point correctly:
include_once ('/usr/local/cpanel/base/3rdparty/wysiwygPro/wysiwygPro.class.php');

// create a new instance of the wysiwygPro class:
$editor = new wysiwygPro();

$editor->registerButton('save', 'Save',
        'do_save();', '##buttonURL##save.gif', 22, 22,
        'savehandler'); 
$editor->addRegisteredButton('save', 'before:print' );
$editor->addJSButtonStateHandler ('savehandler', 'function (EDITOR,srcElement,cid,inTable,inA,range){ 
        return "wproReady"; 
        }'); 


$editor->registerButton('cancel', 'Cancel',
        'do_abort();', '##buttonURL##close.gif', 22, 22,
        'cancelhandler'); 
$editor->addRegisteredButton('cancel', 'before:print' );
$editor->addJSButtonStateHandler ('cancelhandler', 'function (EDITOR,srcElement,cid,inTable,inA,range){ 
        return "wproReady"; 
        }'); 
$editor->theme = 'blue'; 
$editor->addJSEditorEvent('load', 'function(editor){editor.fullWindow();setHtmlFilters(editor);}');

$editor->baseURL = "http://www.cardiopuls.com/public_html/";

$editor->loadValueFromFile('/home/p15lh0tm/public_html/home.html');

$editor->registerSeparator('savecan');

// add a spacer:
$editor->addRegisteredButton('savecan', 'after:cancel');

//$editor->set_charset('iso-8859-1');
$editor->mediaDir = '/home/p15lh0tm/public_html/';
$editor->mediaURL = 'http://www.cardiopuls.com/';
$editor->imageDir = '/home/p15lh0tm/public_html/';
$editor->imageURL = 'http://www.cardiopuls.com/';
$editor->documentDir = '/home/p15lh0tm/public_html/';
$editor->documentURL = 'http://www.cardiopuls.com/';
$editor->emoticonDir = '/home/p15lh0tm/public_html/.smileys/';
$editor->emoticonURL = 'http://www.cardiopuls.com/.smileys/';
$editor->loadPlugin('serverPreview'); 
$editor->plugins['serverPreview']->URL = 'http://www.cardiopuls.com/public_html/.wysiwygPro_preview_4725c0ce919c309d16e2ebd517e25956.php?randomId=hFFHaOjY87TwBd5jSZZR1dfkD4XioeRJuAcDQnyBO6Q796cyTVMMtef6Q8a0opfNMOjSzTu43iQYbUH74hZFdscwcdJuYAmpibmjtnsYKRPqVrZ9cemMeE8pw3lbPD3PFsRb6jh_MxoCeXOcTkTqWOPMHMxf9L0c7U70z4E3xy8mSTw5h2HZbsttnXOHozKQXc94iWMbltDbJQR5Lyj3c5al576pxH3xgcpJelBPN2CErVPhl7YJe012UsGVnN9P';
// print the editor to the browser:
$editor->htmlCharset = 'ISO-8859-1';
$editor->urlFormat = 'relative';
$editor->display('100%','450');

?>
</div>
<script>

</script>

</body>
</html>
<?php ob_end_flush() ?>
