<?php
if ($_GET['randomId'] != "AQlUSEYkDaXr5ltNZl4Il_lNt2VGgfWZavpOgieaHDaMyiwB_CoiRMBrcf8zHx6u") {
    echo "Access Denied";
    exit();
}

// display the HTML code:
echo stripslashes($_POST['wproPreviewHTML']);

?>  
