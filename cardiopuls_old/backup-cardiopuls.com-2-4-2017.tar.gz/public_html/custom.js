//var s3j = .noConflict();
$(document).ready(function(){

  //commonly accesed DOM elements
  var main = $('.on-canvas');
  var mobileNav = $('.mobile-navigation');
  var offCanvasClick = $('.off-canvas-click');
  var header = $('header');

  //page width determines offsets or whether a function should run or not
  //for example parallax() only works on desktop sizes and up
  var pageWidth = $(window).width();

  //Scroll Top Button
  $('.scroll-top').click(function(){
    $('html, body').animate({scrollTop:0}, 500);
  });

  //Smooth scroll function
  //add class ".scoller" to anchor tag with an ID as its href attr
  $('body').on('click', '.scroller', function(e){
    e.preventDefault();
    var offset = function(){
      if(pageWidth < 1024){
        //mobile header size
        return 70;
      } else {
        //desktop header size
        return 155;
      }
    };
    console.log('clickeedddd');
    $('html, body').animate({
      scrollTop: $( $.attr(this, 'href') ).offset().top - offset()
    }, 800, 'easeOutQuart');
  });

  $('.js-menu-toggle').on('click', function(e){
    e.preventDefault();
    if(main.hasClass('menu-is-open')){
      toggleMenu();
    } else {
      toggleMenu();
    }
  });

  //triggers the click on main content, to close mobile nav
  //currently not used
  //todo: figure out a way to allow this to work with jquery.swipe
  offCanvasClick.on('click', function(e){
    e.preventDefault();
    if(offCanvasClick.hasClass('active')){
      toggleMenu();
    }
  });

  //swipe functionality for mobile nav
  main.swipe({
    swipeLeft: function(event, direction, distance, duration, fingerCount){
      if ( pageWidth < 1024 ) {
        toggleMenu();
      }
    },
    swipeRight: function(event, direction, distance, duration, fingerCount){
      if(main.hasClass('menu-is-open')){
        if ( pageWidth < 1024 ) {
          toggleMenu();
        }
      }
    }
  });

  //Menu toggle function
  function toggleMenu(){

    if(!main.hasClass('menu-is-open')){
      $('.js-menu-toggle .title').html('Close');
    } else {
      $('.js-menu-toggle .title').html('Menu');
    }

    //trigger classes for displaying mobile nav
    main.toggleClass('menu-is-open');
    mobileNav.toggleClass('menu-is-open');
    //offCanvasClick.toggleClass('active');
  }

  //open (or close) submenu items in the lateral menu. Close all the other open submenu items.
  $('.mobile-navigation .has-sub > a, .sidebar .has-sub > a').on('click', function(e){
    if(!$(this).parents('header').length && !$(this).parents('footer').length ){
      e.preventDefault();
    }
    if($(this).hasClass('submenu-open')) {
      $(this).removeClass('submenu-open').next('ul').slideUp(400).end();
    } else {
      $(this).addClass('submenu-open').next('ul').slideDown(400).end();
      $(this).parent('.has-sub').siblings('.has-sub').children('a').removeClass('submenu-open').next('ul').slideUp(400);
    }
  });

  //generate sub nav scroller links
  dropdown();

  //original quick links generator
  function quickLinks() {
    if ($('body').hasClass('sub') && !$('.sub-content').hasClass('js-no-links')) {
      $('.sub-content').prepend('<dl>');
      var dl = $('.sub-content dl');
      dl.addClass('sub-nav');
      dl.html('<dt>On this page:</dt>');
      $('.sub-content > h3').each(function () {
        var link = $(this).attr('id');
        var dd = document.createElement('dd');
        var a = document.createElement('a');
        $(a).text($(this).text());
        $(a).addClass('arrow');
        $(a).addClass('scroller');
        $(a).attr({href: '#' + link});
        $(dd).append(a);
        dl.append(dd);
      });
    }
  }

  //fancybox
  $(".fancybox").fancybox({
    autoWidth: true,
    autoHeight: true,
    padding: 0,
    autoResize: true,
    openEffect: 'elastic',
    helpers: {
      overlay: {
        locked: false
      }
    }
  });

  //new dropdown quick links
  function dropdown() {
    if ($('body').hasClass('sub') && !$('.sub-content').hasClass('js-no-links')) {
      $('.sub-content').prepend('<div class="divider"></div>');
      $('.sub-content').prepend('<ul class="subnav">');
      var ul = $('.subnav');
      ul.append('<li class="trigger"><a>Select a section<span class="hide-phone"> to jump to</span><span class="arrow"></span></a></li>');
      var mainLi = $('.trigger');
      mainLi.append('<ul>');
      $('.sub-content > h3').each(function () {
        if(!$(this).hasClass('js-exclude')){
          var link = $(this).attr('id');
          var li = document.createElement('li');
          var a = document.createElement('a');
          $(a).text($(this).text());
          $(a).addClass('arrow');
          $(a).addClass('scroller');
          $(a).attr({href: '#' + link});
          $(li).append(a);
          mainLi.find('ul').append(li);
        }
      });
    }
  }

  $('.subnav .trigger').on('click', function(e){
    $(this).find('ul').slideToggle(200);
  });


  function parallax(){
    var scrolled = $(window).scrollTop();
    //custom parallax animations
    //$('.feat > .row, .feat > .row-outer .row').css('bottom',-(scrolled*0.4)+'px');
    //$('.feat > .row, .feat > .row-outer .row').css('opacity',( 1 - scrolled * 0.62 / 100));
    /*$('.feat > .row-outer').css('opacity',( 1 - scrolled * 0.22 / 100));*/
    $('.main-slider .row-outer').css('opacity',( 1 - scrolled * 0.32 / 100));
  }

  function headerAnimate(){
    var scrollTop = $(window).scrollTop();
    //remove .js-animate from the header HTML in order to prevent header animation
    if(header.hasClass('js-animate')){
      //scroll > n, where n is an arbitrary value, can be different per site
      if(scrollTop > 120) {
        header.addClass('scrolled');
      } else {
        header.removeClass('scrolled');
      }
    }
  }

  //functions to run on scroll
  $(window).scroll(function(){
    //only run parallax if on desktop screen
    //(mobile parallax interferes with content consumption)
    if ( pageWidth > 1024 ) {
      parallax();
      headerAnimate();
    }
  });

  $('.s3accordion > .s3panel > a').on('click', function(e){
    e.preventDefault();
    if(!$(this).parent().hasClass('js-opened')){
      //$('.js-opened').find('div').slideUp();
      $(this).next().slideDown();
      $(this).parent().addClass('js-opened');
    } else {
      $(this).next().slideUp();
      $(this).parent().removeClass('js-opened');
    }
  });


});
