<?php
if ($_GET['randomId'] != "hFFHaOjY87TwBd5jSZZR1dfkD4XioeRJuAcDQnyBO6Q796cyTVMMtef6Q8a0opfNMOjSzTu43iQYbUH74hZFdscwcdJuYAmpibmjtnsYKRPqVrZ9cemMeE8pw3lbPD3PFsRb6jh_MxoCeXOcTkTqWOPMHMxf9L0c7U70z4E3xy8mSTw5h2HZbsttnXOHozKQXc94iWMbltDbJQR5Lyj3c5al576pxH3xgcpJelBPN2CErVPhl7YJe012UsGVnN9P") {
    echo "Access Denied";
    exit();
}

// display the HTML code:
echo stripslashes($_POST['wproPreviewHTML']);

?>  
